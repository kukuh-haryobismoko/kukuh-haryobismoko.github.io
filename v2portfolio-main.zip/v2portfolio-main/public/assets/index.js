import nextjs from "./img/projects/nextjs.jpg";
import reactjs from "./img/projects/reactjs.jpg";
import laravel from "./img/projects/laravel.jpg";
import codeigniter from "./img/projects/codeigniter.jpg";
import vuejs from "./img/projects/vuejs.jpg";
import nuxtjs from "./img/projects/nuxtjs.jpg";
export { nextjs, reactjs, laravel, codeigniter, vuejs, nuxtjs };
